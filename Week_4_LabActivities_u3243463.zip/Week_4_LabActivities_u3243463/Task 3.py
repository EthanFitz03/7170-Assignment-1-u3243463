import timeit
import random

# Now that we've gotten some background on searching algorithms, let's
# try and implement some basic ones. First, we'll try the most basic of all:
# linear search. Despite its simplicity, linear search is actually the
# algorithm that Python lists use when we check membership with the 'in'
# keyword.
#
# Note that with the Python data structures we're using here, the function
# of these algorithms is not necessary (as the Python structures already
# implement searching, sorting, etc.). We are doing it for the sake of
# learning the theory. In practice, it is recommended to use the
# built in searching functions!


# LINEAR SEARCH
def linear_search(array, target):

    for i in range(len(array)):
        if array[i] == target:
            return i

    return -1


test = range(1000000)
print(linear_search(test, 99999))
print(linear_search(test, -999))


# BINARY SEARCH
def binary_search(array, target):

    left = 0
    right = len(array) - 1
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target:
            return mid
        elif target > array[mid]:
            left = mid + 1
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2)

    return -1


test = [1, 1, 1, 2, 3, 6, 9, 19, 555]
print(binary_search(test, 1))
print(binary_search(test, 555))

sorted_list = list(range(1000000))
target = random.randint(0, 999999)
linear_time = timeit.timeit(lambda: linear_search(sorted_list, target), number=100)
binary_time = timeit.timeit(lambda: binary_search(sorted_list, target), number=100)

print(f"Linear search execution time: {linear_time:.6f} seconds")
print(f"Binary search execution time: {binary_time:.6f} seconds")


# SORTING ALGORITHMS
# Another major category of algorithm is the sorting algorithm. Sorting algorithms
# are used to sort collections of elements into sorted order (such as numerical order for lists of numbers).


# BUBBLE SORT
def bubble_sort(arr):
    """
    Bubble Sort: A simple sorting algorithm that repeatedly steps through the list,
    compares adjacent elements, and swaps them if they are in the wrong order.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):

        # Flag to optimize the algorithm
        swapped = False

        # Last i elements are already in place, so we don't need to compare them again
        for j in range(0, n - i - 1):

            # Compare adjacent elements
            if arr[j] > arr[j + 1]:

                # Swap if the element found is greater than the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, the list is sorted, and we can exit early
        if not swapped:
            break

    return arr


# Example usage:
unsorted_list = [64, 25, 12, 22, 11]
sorted_list = bubble_sort(unsorted_list)
print("Sorted array:", sorted_list)


# INSERTION SORT
def insertion_sort(arr):
    """
    Insertion Sort: A simple sorting algorithm that builds the final sorted
    array one item at a time. It takes each element from the input list and
    inserts it into its correct position in the sorted part of the array.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr


# Example usage:
unsorted_list = [64, 1, 12, 22, 11]
sorted_list = insertion_sort(unsorted_list)
print("Sorted array:", sorted_list)

# Comparing bubble sort and insertion sort
# Generate a random unsorted list of 1000 integers
unsorted_list = [random.randint(1, 1000) for _ in range(10000)]

# Measure and compare the runtimes of Bubble Sort and Insertion Sort
bubble_sort_time = timeit.timeit(lambda: bubble_sort(unsorted_list.copy()), number=1)
insertion_sort_time = timeit.timeit(lambda: insertion_sort(unsorted_list.copy()), number=1)

print(f"Bubble Sort Execution Time: {bubble_sort_time:.6f} seconds")
print(f"Insertion Sort Execution Time: {insertion_sort_time:.6f} seconds")

# Both bubble sort and insertion sort are quite inefficient, since their runtime scales
# exponentially with the number of elements. However, they are useful for demonstrating
# the principles of sorting algorithms.


# Additional tests shown in same file

print("\n")
print("Task 2: Insertion sort result")


insertion_test_lists = [
    [64, 1, 12, 22, 11],
    [9, 4, 7, 1, 3, 6, 2],
    [15, 10, 8, 22, 5, 1, 19, 3]
]

for index, test_list in enumerate(insertion_test_lists, start=1):
    print(f"\nInsertion Sort Test {index}")
    print("Unsorted list:", test_list)
    print("Sorted list:", insertion_sort(test_list.copy()))


print("\n")
print("Task 2: Bubble sort result")


bubble_test_lists = [
    [64, 25, 12, 22, 11],
    [5, 1, 4, 2, 8],
    [20, 3, 15, 7, 9, 1]
]

for index, test_list in enumerate(bubble_test_lists, start=1):
    print(f"\nBubble Sort Test {index}")
    print("Unsorted list:", test_list)
    print("Sorted list:", bubble_sort(test_list.copy()))


print("\n")
print("Task 2: Runtime comparison of Bubble and Insertion")


runtime_sizes = [100, 1000, 5000, 10000]

for size in runtime_sizes:
    unsorted_list = [random.randint(1, 1000) for _ in range(size)]

    bubble_sort_time = timeit.timeit(lambda: bubble_sort(unsorted_list.copy()), number=1)
    insertion_sort_time = timeit.timeit(lambda: insertion_sort(unsorted_list.copy()), number=1)

    print(f"\nData size: {size}")
    print(f"Bubble Sort Execution Time: {bubble_sort_time:.6f} seconds")
    print(f"Insertion Sort Execution Time: {insertion_sort_time:.6f} seconds")